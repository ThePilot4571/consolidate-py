from consolidate import consolidatemodule
print("Initialized consolidatepy!")