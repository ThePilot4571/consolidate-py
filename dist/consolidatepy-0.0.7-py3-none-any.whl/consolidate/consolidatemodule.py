def generate(a, b, c):
    return a + b + c