def consolidate(base, fill, len):
    output = []
    
    """
    Generate a list of possible combinations where .

    :param str baseString: String to put fillerString within
    :param str fillerString : String to put within baseString
    :param int maxLength: Max length of result string
    :return: List of combinations
    :rtype: list
    """
    # maybe add a "must match max length" bool as an input if user requires exact length, no less
    
print(consolidate(1,2,3))